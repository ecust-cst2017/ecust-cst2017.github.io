#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635

 
int  findsub(char *str1,char *str2)
{
	int i=0,j;
	while(str1[i])
	{
		for(;str1[i]!=str2[0];i++);
		if(str1[i]==str2[0])
		{
			for(j=0;str1[i+j]!='\0'&&str1[i+j]==str2[j];j++);
			if(str2[j]=='\0')
			{
				return i+1;
			}
		    i++;
		}
	}
	return -1;
}
main()
{
	char *s1="wherever",*s2="er";
	printf("%d",findsub(s1,s2));
}