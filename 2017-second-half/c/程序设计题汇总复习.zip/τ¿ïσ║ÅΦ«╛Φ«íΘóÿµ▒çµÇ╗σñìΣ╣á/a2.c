#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
//  P63  5.10 爱因斯坦问题
main()
{
	int i=0;
	while(1)
		{
			i=i+7;
			if(i%2==1&&i%3==2&&i%5==4&&i%6==5)
				break;
		}
	printf("%d\n",i );
}