#include<stdio.h>
//**补充题，先输入n个数，实现逆序排列**
void main(){
	printf("请输入要输入的数字的个数:");
	int a[20],i,j,n,t;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0,j=n-1;i<j;i++,j--){
		t=a[i];a[i]=a[j];a[j]=t;
	}
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
