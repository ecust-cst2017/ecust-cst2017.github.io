#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
//  desc: 
//  P85 6.8  由键盘输入一个同学的姓名，查找在指定的班级中是否存在
main()
{
	printf("请输入你要查询的人名：");
	char b[][10]={"zhangsan","lisi","wangwu","zhaoliu"};
	char a[10];
	int i,yn=0;
	gets(a);
	for(i=0;i<6;i++)
	{
		if(strcmp(a,b[i])==0)
		{
			yn=1;printf("Found at %d",i);
		}
	}
	if(yn==0)
	{
		printf("Not Found");
	}
}