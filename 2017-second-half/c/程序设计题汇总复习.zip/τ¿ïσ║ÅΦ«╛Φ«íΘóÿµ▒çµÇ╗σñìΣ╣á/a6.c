#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
//  desc:  2个字符串拼接
//  P85 2个字符串拼接
main()
{
	char a[]="zhangsan",b[]="wangwu",c[20];
	int i=0,j=0;
	while(a[i])
	{
		c[i]=a[i];i++;
	}
	while(b[j])
	{
		c[i+j]=b[j];j++;
	}
	c[i+j]='\0';
	puts(c);
}