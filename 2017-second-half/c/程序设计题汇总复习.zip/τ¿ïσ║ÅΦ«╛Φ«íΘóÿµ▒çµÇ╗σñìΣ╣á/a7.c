#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635

 
int  isprime(int n)
{
	int i,yn=1;
	for(i=2;i<=n/2;i++)
		if(n%i==0)
		{
			yn=0;
		}
	return yn;
}
main()
{
	int m,n;
	scanf("%d",&m);
	for(n=3;n<m;n++)
	{
		if(isprime(n))
		{
			printf("%d", n);
		}
	}
}