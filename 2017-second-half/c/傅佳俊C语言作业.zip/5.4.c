//
//  main.c
//  5.4
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>
//  5.4
main ()
{
    int i,j,n = 1,m = 1;
    int sum = 0;
    for(i=1; i<=10; i++)
    {
        for(j=1; j<=i; j++)
        {
            if(j==i)
            {
                n = m*j;
                m = n;//记录当前阶乘的积
            }
        }
        sum += n;
    }
    printf("sum=%d\n",sum);
}

