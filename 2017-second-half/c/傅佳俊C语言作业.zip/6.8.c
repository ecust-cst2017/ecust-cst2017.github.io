//
//  main.c
//  6.8
//
//  Created by 傅佳俊 on 2017/12/13.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include "string.h"
//6.8
main() {
//    // insert code here...
    char a[10][10]={"Mary","Tom","John"};
    char b[10][10]={"Wang","Sun","Zhao"};
    char c[10][10]={"Li","Huang","Ni"};
    char name[10];
    char class[10];
    int i,none=0;
    printf("输入学生名字");
    scanf("%s",&name);
    printf("输入学生班级");
    scanf("%s",&class);
    if (strcmp(class,"a")==0) {
        for (i=0; i<10; i++) {
            if (strcmp(a[i], name)==0) {
                printf("%s %s班",name,class);
                none=1;
                break;
            }
        }
        if (none==0) {
            printf("%s 不在%s班",name,class);
        }
    }
    else if (strcmp(class,"b")==0) {
        for (i=0; i<10; i++) {
            if (strcmp(b[i], name)==0) {
                printf("%s %s班",name,class);
                none=1;
                break;
            }
        }
        if (none==0) {
            printf("%s 不在%s班",name,class);
        }
    }
    else if (strcmp(class,"c")==0) {
        for (i=0; i<10; i++) {
            if (strcmp(c[i], name)==0) {
                printf("%s %s班",name,class);
                none=1;
                break;
            }
        }
        if (none==0) {
            printf("%s 不在%s班",name,class);
        }
    }
    else {
        printf("没有该班级");
    }
}

