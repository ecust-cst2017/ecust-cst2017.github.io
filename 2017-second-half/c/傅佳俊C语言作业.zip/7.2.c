//
//  main.c
//  7.2
//
//  Created by 傅佳俊 on 2017/12/17.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//7.2
long factor(int k){
    if (k==0) {
        return 1;
    }
    else
        return k*factor(k-1);
}

main() {
//    // insert code here...
    int m,n;
    printf("输入m值");
    scanf("%d",&m);
    printf("输入n值");
    scanf("%d",&n);
    printf("%d",factor(m)/(factor(n)*factor(m-n)));
}

