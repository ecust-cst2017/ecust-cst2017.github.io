//
//  main.c
//  6.11
//
//  Created by 傅佳俊 on 2017/12/13.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include <math.h>
#include "string.h"
//6.11
main() {
    //     insert code here...
    char str[10];
    int i,sum=0;
    long m;
    scanf("%s",str);
    m=strlen(str);
    for (i=0; i<m; i++) {
        if(str[i]>='A' && str[i]<='Z')
            str[i]=(int)(str[i]-'A')+10+'0';
        sum+=((str[i]-'0')* (pow(16,m-1-i)));
    }
    printf("%d\n",sum);
}

