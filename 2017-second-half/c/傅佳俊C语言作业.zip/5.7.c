//
//  main.c
//  5.7
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>
//  5.7
main ()
{
    int i,j;
        
        for(i=0;i<5;i++)        //共n行
            
        {
            
            for(j=0;j<i;j++)//前面的空格
                printf("  ");
            
            for(j=0;j<2*(5-i)-1;j++)        //输出一行上的“*”
            {
                printf("* ");
            }
            
            printf("\n");                //一行结束，换行
            
        }
}

