//
//  main.c
//  5.6
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//5.6
main() {
    // insert code here...
    int i,sign=-1;
    float sum=0;
    for (i=1; i<11; i++) {
        sign=-sign;
        sum=sum+sign*((float)(i*i)/(2*i+1));
    }
    printf("%f",sum);
}
