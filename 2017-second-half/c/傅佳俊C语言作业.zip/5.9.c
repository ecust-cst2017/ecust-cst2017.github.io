//
//  main.c
//  5.9
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  5.9
#include <stdio.h>
main ()
{
    int a=1,b=1,c;
    for (c=1; c<=20; c++)
    {
        if (c==1 || c==2 )
        {
            printf("1 ");
        }
        else if((c%2)!=0)
        {
            a=a+b;
            printf("%d ",a);
        }
        else if((c%2)==0)
        {
            b=a+b;
            printf("%d ",b);
        }
//        printf("%d\n",c);
    }
}

