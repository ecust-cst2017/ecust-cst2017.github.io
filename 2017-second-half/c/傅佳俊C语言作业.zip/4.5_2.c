//
//  main.c
//  4.5_2
//
//  Created by 傅佳俊 on 2017/11/12.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  4.5_2
main() {
    // insert code here...
    int x;
    printf("请输入成绩");
    scanf("%d",&x);
    if(x>=90)
        printf("成绩A等");
    else if(x>=80 && x<90)
        printf("成绩B等");
    else if(x>=70 && x<80)
        printf("成绩C等");
    else if(x>=60 && x<70)
        printf("成绩D等");
    else if(x<60)
        printf("成绩E等");
}

