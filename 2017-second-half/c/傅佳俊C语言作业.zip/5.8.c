//
//  main.c
//  5.8
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>
//  5.8
main ()
{
    int a,b,c;
    for(a=1;a<=9;a++)
    {
        for(b=1;b<=a;b++)
        {
            c=a*b;
            printf("%d*%d=%d ",a,b,c);
        }
        printf("\n");
    }
}

