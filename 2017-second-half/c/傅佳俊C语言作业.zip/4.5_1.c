//
//  main.c
//  4.5_1
//
//  Created by 傅佳俊 on 2017/11/12.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  4.5_1
main() {
    // insert code here...
    int x;
    printf("请输入成绩");
    scanf("%d",&x);

    switch (x/10) {
        case 10:
            printf("成绩A等\n");
            break;
            
        case 9:
            printf("成绩A等\n");
            break;
            
        case 8:
            printf("成绩B等\n");
            break;
            
        case 7:
            printf("成绩C等\n");
            break;
            
        case 6:
            printf("成绩D等\n");
            break;
            
        default:
            printf("成绩E等\n");
            break;
    }
}

