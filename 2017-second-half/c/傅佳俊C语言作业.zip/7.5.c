//
//  main.c
//  7.5
//
//  Created by 傅佳俊 on 2017/12/18.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#define N 10
int collect(float s[],int n,float *aver)
{
    int i,count=0;
    float x=0.0;
    for (i=0; i<N; i++) {
        x+=s[i];
    }
    x=x/N;
    for (i=0;  i<N; i++) {
        if (s[i]<x)
            count++;
    }
    *aver=x;
    return count;
}

main() {
    float s[N],aver;
    int i,num;
    for (i=0; i<N; i++) {
        scanf("%f",&s[i]);
    }
    num=collect(s, N, &aver);
    printf("average=%.1f\n",aver);
    printf("<%.1f is:%d\n",aver,num);
}
