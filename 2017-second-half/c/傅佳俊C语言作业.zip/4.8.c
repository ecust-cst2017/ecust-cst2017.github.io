//
//  main.c
//  4.8
//
//  Created by 傅佳俊 on 2017/11/12.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  4.8
main() {
    // insert code here...
    int a,b,c,x;
    printf("请输入年份");
    scanf("%d",&x);
    if(x%400==0)
        printf("%d是闰年",x);
    else if(x%4==0 && x%100!=0)
        printf("%d是闰年",x);
    else
        printf("%d不是闰年",x);
}

