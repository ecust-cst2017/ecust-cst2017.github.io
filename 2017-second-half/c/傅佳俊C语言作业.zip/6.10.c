//
//  main.c
//  6.10
//
//  Created by 傅佳俊 on 2017/12/10.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//6.10
main() {
//    // insert code here...
    char s1[20]="myname";
    char s2[10]="fujiajun";
    int i=0,j=0;
    while (s1[i]!='\0') {
        i++;
    }
    while (s2[j]!='\0') {
        s1[i]=s2[j];
        j++;
        i++;
    }
    printf("%s\n",s1);
}

