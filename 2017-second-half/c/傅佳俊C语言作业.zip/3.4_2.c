//
//  main.c
//  3.4_2
//
//  Created by 傅佳俊 on 2017/11/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  3.4_2
main() {
    // insert code here...
    int a,b;
    float c;
    scanf(" input a&b: %d %d",&a,&b);
    c=(float)a/(float)(b);
    printf("a=%d b=%d c=%f\n",a,b,c);
}

