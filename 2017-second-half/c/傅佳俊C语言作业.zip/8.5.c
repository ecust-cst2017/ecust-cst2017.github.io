//
//  main.c
//  8.5
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//8.5
int search(int *ap,int n,int key){
    int i=0;
    while (i<n&&ap[i]!=key) {
        i++;
    }
    if (i==n) {
        return -1;
    }
    else{
        return i;
    }
}
main() {
    //    // insert code here...
    int a[]={1,2,3,4,5,6,7,8,9,10,11},key=3,n=5;
    printf("%d",search(a, n, key));
}



