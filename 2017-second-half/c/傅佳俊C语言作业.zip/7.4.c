//
//  main.c
//  7.4
//
//  Created by 傅佳俊 on 2017/12/19.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//7.4
//int digit(long n,int k){
//    while (n&&k>1) {
//        n/=10;
//        k--;
//    }
//    return n%10;
//}
//
//main() {
////    // insert code here...
//    long x=52761;
//    printf("digit(%1d,4)=%d\n",x,digit(x, 4));
//}

int gys(int a,int b) {
    int r;
    r=a%b;
    printf("%d\n",r);
    if (r) {
        a=b;
        b=r;
        return gys(a, b);
    }
    else
        return b;
}

main() {
    int x[]={18,24,15,45};
    printf("%d\t%d\t%d\n",x[0],x[1],gys(x[0], x[1]));
    printf("%d\t%d\t%d\n",x[2],x[3],gys(x[2], x[3]));
}
