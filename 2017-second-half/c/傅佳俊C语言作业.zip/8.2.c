//
//  main.c
//  8.2
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//8.2
double round(double *a,double *b){
    if (*a>*b) {
        *a=(long)(*a*10000+0.5)/10000.0;
        *b=(long)(*b*10000)/10000.0;
    }
    else{
        *a=(long)(*a*10000)/10000.0;
        *b=(long)(*b*10000+0.5)/10000.0;
    }
    return 0;
}
main() {
    //    // insert code here...
    double x=12.23456,y=10.5678;
    round(&x,&y)
    printf("%1f,%1f\n",x,y);
}



