//
//  main.c
//  8.7
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//8.7
void printstring(char *x){
    int length,left,right;
    for (length=0; x[length]!='\0'; length++);
    if (length%2!=0) {
        left=0,right=1;
    }
    else{
        putchar(x[length/2]);
        left=1,right=1;
    }
    length/=2;
    while (left<=length) {
        putchar(x[length-left]);
        putchar(x[length+right]);
        left++;
        right++;
    }
    return;
}

main() {
    //    // insert code here...
    char str[]="123456";
    printstring(str);
}



