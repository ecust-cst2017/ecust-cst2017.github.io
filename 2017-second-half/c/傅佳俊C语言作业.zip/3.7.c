//
//  main.c
//  3.7
//
//  Created by 傅佳俊 on 2017/11/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  3.7
main() {
    // insert code here...
    char a,b,c,d;
    printf("输入2个字符（getchar方法）");
    a=getchar();
    b=getchar();
    getchar();
    putchar(a);
    putchar(b);
    putchar('\t');
    printf("ascii %d %d\n",a,b);
    printf("输入2个字符（scanf方法）");
    scanf("%c%c",&c,&d);
    printf("%c%c\t",c,d);
    printf("ascii %d %d\n",c,d);
}

