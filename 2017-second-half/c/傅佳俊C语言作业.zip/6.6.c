//
//  main.c
//  6.6
//
//  Created by 傅佳俊 on 2017/12/11.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//6.6
main() {
//    // insert code here...
    int a[2][3],b[3][2],i,j;
    for (i=0; i<2; i++) {
        for (j=0; j<3; j++) {
            scanf("%d",&a[i][j]);
        }
    }
    for (i=0; i<3; i++) {
        for (j=0; j<2; j++) {
            b[i][j]=a[j][i];
            printf("%2d",b[i][j]);
        }
        printf("\n");
    }
}
