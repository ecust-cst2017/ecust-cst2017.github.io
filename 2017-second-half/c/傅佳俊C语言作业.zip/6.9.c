//
//  main.c
//  6.10
//
//  Created by 傅佳俊 on 2017/12/10.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include <math.h>
//6.10
main() {
//    // insert code here...
    char s1[20],s2[20];
    printf("输入第一个字符串\n");
    scanf("%s",s1);
    printf("输入第二个字符串\n");
    scanf("%s",s2);
    int i=0,j=0,n,sum=0,result=0;
    //判断字符长度
    while (s1[i]!='\0') {
        i++;
    }
//    printf("%d",i);
    while (s2[j]!='\0') {
        j++;
    }
//    printf("%d",j);
    for (n=0; n<=i && n<=j; n++) {
//        printf("%d",(int)s1[n]);
//        printf("%d",(int)s2[n]);
        if ((int)s1[n]==(int)s2[n]) {
            result=0;
        }
        if ((int)s1[n]>(int)s2[n]) {
            result=1;
            sum=fabs((int)s1[n]-(int)s2[n]);
            break;
        }
        else if ((int)s1[n]<(int)s2[n]) {
            result=-1;
            sum=fabs((int)s1[n]-(int)s2[n]);
            break;
        }
    }
    if (result==0) {
        printf("%s=%s ASCII码差值%d\n",s1,s2,sum);
    }
    else if (result>0) {
        printf("%s>%s ASCII码差值%d\n",s1,s2,sum);
    }
    else if (result<0) {
        printf("%s<%s ASCII码差值%d\n",s1,s2,sum);
    }
//    printf("%d",n);
}
