//
//  main.c
//  6.3
//
//  Created by 傅佳俊 on 2017/12/11.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//6.3
main() {
//    // insert code here...
    int a[10];
    int min=0,max=0,i=0;
    float sum=0;
    printf("please input :");
    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
        if (i==0) {
            min=a[0];
            max=a[0];
        }
        sum+=a[i];
        printf("%d%d\n",min,max);
        if(a[i]>max)
            max=a[i];
        if(a[i]<min)
            min=a[i];
        printf("%d%d\n",min,max);
    }
    printf("%f",sum);
    printf("平均值为:%f",(sum-min-max)/8);
}
