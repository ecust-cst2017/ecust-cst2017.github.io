//
//  main.c
//  8.8
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//8.8
int cmp(char *a,char *b){
    int i=0;
    while (a[i]!='\0' && b[i]!='\0' && a[i]==b[i]) {
        i++;
    }
    if (a[i]==b[i]) {
        return 0;
    }
    if (a[i]>b[i]) {
        return 1;
    }
    else{
        return -1;
    }
}

main() {
    //    // insert code here...
    char str1[10],str2[10];
    printf("输入2个字符串");
    scanf("%s%s",str1,str2);
    printf("%d\n",cmp(str1,str2));
}



