//
//  main.c
//  5.1
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>
#include <math.h>

//  5.1
main()
{
    int x,num;
    scanf("%d",&num);
    while (num!=0)
    {
        if(num<0)
            printf("-");
            num = fabs(num);
        do
        {
            x=num%10;
            printf("%d",x);
        }
        while ((num=num/10)>0);
        if(num==0)
            printf("\n");
        scanf("%d",&num);
    }
}

