//
//  main.c
//  7.7
//
//  Created by 傅佳俊 on 2017/12/19.
//  Copyright © 2017年 fujiajun. All rights reserved.
//


#include <stdio.h>
//7.7
int isprime(int n)
{
    int i;
    for(i=2;i<=n/2;i++)
        if(n%i==0)
            return 0;
    return 1;
}
main() {
//    // insert code here...
    int i;
    for (i=3; i<100; i++) {
        if (isprime(i)==1) {
            printf("%d ",i);
        }
    }
    printf("\n");
}

