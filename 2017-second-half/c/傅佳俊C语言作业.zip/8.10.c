//
//  main.c
//  8.10
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#define N 4
//8.10
void sort(char *name[N],char *address[N],int tag){
    int i,j;
    char *temp;
    if (tag==0) {
        for (i=0; i<4; i++) {
            for (j=0; j<3-i; j++) {
                if (strcmp(name[j], name[j+1])>0) {
                    temp=name[j];
                    name[j]=name[j+1];
                    name[j+1]=temp;
                    temp=address[j];
                    address[j]=address[j+1];
                    address[j+1]=temp;
                }
            }
        }
    }
    if (tag==1) {
        for (i=0; i<4; i++) {
            for (j=0; j<3-i; j++) {
                if (strcmp(address[j], address[j+1])>0) {
                    temp=name[j];
                    name[j]=name[j+1];
                    name[j+1]=temp;
                    temp=address[j];
                    address[j]=address[j+1];
                    address[j+1]=temp;
                }
            }
        }
    }
}

main() {
    //    // insert code here...
    char *name[]={"ZhangSan","TaoDa","WangXiao","LiSi"};
    char *address[]={"No.300 MeiLong Road","No.70 ZhenBai Road Building 28,Room 403","No.1000 HuaiHai","No.81 XingHua Road"};
    int i,tag;
    for (i=0; i<4; i++) {
        printf("%s %s\n",name[i],address[i]);
    }
    printf("输入排序模式 0 or 1\n");
    scanf("%d",&tag);
    sort(name, address,tag);
    for (i=0; i<4; i++) {
        printf("%s %s\n",name[i],address[i]);
    }
}



