//
//  main.c
//  3.4_1
//
//  Created by 傅佳俊 on 2017/11/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>

main() {
    // insert code here...
    int x,y;
    x=76543;
    y=123.456;
    printf("%d %d\n",x,y);
}
