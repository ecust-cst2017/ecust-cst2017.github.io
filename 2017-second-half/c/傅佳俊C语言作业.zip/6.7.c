//
//  main.c
//  6.7
//
//  Created by 傅佳俊 on 2017/12/13.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//6.7
main() {
//    // insert code here...
    int i,j,a[3][4],max,col,temp;
    for (i=0; i<3; i++) {
        for (j=0; j<4; j++) {
            scanf("%d",&a[i][j]);
        }
    }
    for (i=0; i<3; i++) {
        for (j=0; j<4; j++) {
            printf("%4d",a[i][j]);
        }
        printf("\n");
    }
    for (i=0; i<3; i++) {
        max=a[i][0];
        for (j=0; j<4; j++) {
            if (a[i][j]>max) {
                max=a[i][j];
                col=j;
            }
        }
        temp=a[i][col];
        a[i][col]=a[i][0];
        a[i][0]=temp;
    }
    printf("\n");
    for (i=0; i<3; i++) {
        for (j=0; j<4; j++) {
            printf("%4d",a[i][j]);
        }
        printf("\n");
    }
}
