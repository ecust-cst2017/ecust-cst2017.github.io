//
//  main.c
//  6.4
//
//  Created by 傅佳俊 on 2017/12/11.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include "string.h"
//6.4
main() {
//    // insert code here...
    int i=0,j=0,n=0,m,max;
    char a[]="hgvc",b[]="nsdx",c[]="";
    while (a[i]!='\0') {
        i++;
    }
    while (b[j]!='\0') {
        a[i]=b[j];
        j++;
        i++;
    }
    printf("%s\n",a);
    for (i=0; i<strlen(a)-1; i++) {
        for (j=0; j<strlen(a)-i-1; j++) {
            if ((int)a[j]>(int)a[j+1]) {
                n=a[j];
                a[j]=a[j+1];
                a[j+1]=n;
            }
            
        }
    }
    printf("%s\n",a);
}
