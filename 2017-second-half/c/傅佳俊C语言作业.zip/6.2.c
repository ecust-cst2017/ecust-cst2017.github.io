//
//  main.c
//  6.2
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#define M 3
#define N 4
//6.2
main() {
//    // insert code here...
    int a[M][N],max,i,j;
    int row,column;
    for (i=0; i<M; i++) {
        for (j=0; j<N; j++) {
            scanf("%d",&a[i][j]);
        }
    }
    max=0;
    for (i=0; i<M; i++) {
        for (j=0; j<N; j++) {
            if (max<a[i][j]) {
                max=a[i][j];
                row=i;
                column=j;
            }
        }
    }
    printf("\nmax=%d,row=%d,column=%d\n",max,row,column);
}

