//
//  main.c
//  6.1
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//6.1(一)
//main() {
//    // insert code here...
//    int a[6]={0,1,2,3,4};
//    int i,c=0,d=0;
//    for (i=0; i<=3; i++) {
//        a[i+1]=a[i]+c+d+1;
//        c=c+d+d+3;
//        d=d+3;
//        printf("%d\n",a[i]);
//    }
//}
//6.1(二)
//main(){
//    int a[3][3],i,j;
//    for (i=0; i<3; i++) {
//        for (j=0; j<3; j++) {
//            a[i][j]=i+j;
//        }
//    }
//    for (i=0; i<3; i++) {
//        for (j=0; j<3; j++) {
//            printf("%4d",a[i][j]);
//        }
//    printf("\n");
//    }
//}
//6.1(三)
main(){
    char str1[10]=" Guest";
    char str2[10]=" Tom\'s\x20pen";
    puts(str2);
    strcpy(str1,str2);
    printf("%d",strlen(str1));
}
