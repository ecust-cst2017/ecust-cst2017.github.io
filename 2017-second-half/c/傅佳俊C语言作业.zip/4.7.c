//
//  main.c
//  4.7
//
//  Created by 傅佳俊 on 2017/11/12.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  4.7
main() {
    // insert code here...
    int a,b,c,x;
    printf("请输入三位整数");
    scanf("%d",&x);
    a=x/100;
    b=x/10%10;
    c=x%10;
    if(x<100||x>999)
        printf("输入有误\n");
    else if(a*a*a+b*b*b+c*c*c==x)
        printf("%d为水仙花数",x);
    else
        printf("%d不是水仙花数",x);
}

