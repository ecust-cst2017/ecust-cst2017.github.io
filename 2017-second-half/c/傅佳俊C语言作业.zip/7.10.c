//
//  main.c
//  7.10
//
//  Created by 傅佳俊 on 2017/12/19.
//  Copyright © 2017年 fujiajun. All rights reserved.
//


#include <stdio.h>
//7.10
int find_no_k(int x[],int k,int y[2]){
    int i,j,n,temp,a[10];
    for (i=0; i<8; i++) {
        a[i]=x[i];
    }
    for (i=0; i<8; i++) {
        for (j=0; j<8; j++) {
            if (a[j]<a[j+1]) {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
        j=0;
        while (a[k-1]!=x[j]) {
            j++;
        }
        y[0]=a[k-1];
        y[1]=j+1;
    }
    return 0;
}

main() {
//    // insert code here...
    int a[8]={5,2,3,11,0,-6,22,-10},y[2],k=3;
    find_no_k(a, k, y);
    printf("%d,%d\n",y[0],y[1]);
}




