//
//  main.c
//  4.3
//
//  Created by 傅佳俊 on 2017/11/12.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  4.3
main() {
    // insert code here...
    int x;
    printf("请输入1到7的一个整数");
    scanf("%d",&x);
    switch (x) {
        case 1:
            printf("MONDAY\n");
            break;
            
        case 2:
            printf("TUESDAY\n");
            break;
            
        case 3:
            printf("WEDNESDAY\n");
            break;
            
        case 4:
            printf("THURSDAY\n");
            break;
            
        case 5:
            printf("FRIDAY\n");
            break;
            
        case 6:
            printf("SATURDAY\n");
            break;
            
        case 7:
            printf("SUNDAY\n");
            break;
            
        default:
            printf("输入错误\n");
            break;
    }
}

