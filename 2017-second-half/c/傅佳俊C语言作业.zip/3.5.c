//
//  main.c
//  3.5
//
//  Created by 傅佳俊 on 2017/11/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  3.5
main() {
    // insert code here...
    int a,b,c,n,m;
    printf("输入一个三位数\n");
    scanf("%d",&m);
    if(m<100||m>999)
        printf("输入有误：\n");
    a=m/100;
    b=m/10%10;
    c=m%10;
    n=b*100+a*10+c;
    printf("%d\n",n);
}

