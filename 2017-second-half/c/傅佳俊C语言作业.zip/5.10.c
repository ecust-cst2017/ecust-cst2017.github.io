//
//  main.c
//  5.10
//
//  Created by 傅佳俊 on 2017/12/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//5.10
main() {
    // insert code here...
    int x=7;
    while (!(x%2==1&&x%3==2&&x%5==4&&x%6==5)) {
        x+=7;
    }
    printf("%d\n",x);
}
