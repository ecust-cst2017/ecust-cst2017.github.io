//
//  main.c
//  3.6
//
//  Created by 傅佳俊 on 2017/11/3.
//  Copyright © 2017年 fujiajun. All rights reserved.
//
//  计科172_傅佳俊_26170613

#include <stdio.h>


//  3.6
main() {
    // insert code here...
    float a,b,c;
    scanf("%f %f %f",&a,&b,&c);
    printf("%.1f\n",a+b+c);
}

