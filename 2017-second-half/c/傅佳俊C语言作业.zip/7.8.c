//
//  main.c
//  7.8
//
//  Created by 傅佳俊 on 2017/12/19.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#include "string.h"
//7.8


void longstr(char *string)
{
    int i=0, j=0, n, temp=0, m=0, result=0;
    char mid[20],word[20];
    n = strlen(string);
    m = 0;
    for (i = 0; i <= n; i++){
        if ((string[i] >= 'a' && string[i] <= 'z') || (string[i] >= 'A' && string[i] <= 'Z')){
            result = 1;
            mid[j++] = string[i];
        }
        else if (result == 1){
            if (j > temp){
                for (m = 0; m < j; m++)
                    word[m] = mid[m];
                word[m] = '\0';
                temp = j;
            }
            result = 0;
            j = 0;
        }
    }
    printf("%s",word);
}

main() {
    //    // insert code here...
    char str[20];
    gets(str);
    longstr(str);
}





