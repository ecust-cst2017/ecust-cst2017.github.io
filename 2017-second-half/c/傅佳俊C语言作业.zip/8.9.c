//
//  main.c
//  8.9
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
#define K 6
//8.9
void bubble(int *a[],int n){
    int i,j,temp;
    for (i=0; i<n-1; i++) {
        for (j=0; j<n-1-i; j++) {
            if (*a[j]>*a[j+1]) {
                temp=*a[j];
                *a[j]=*a[j+1];
                *a[j+1]=temp;
            }
        }
    }
}

main() {
    //    // insert code here...
    int x[K]={1,3,5,2,6,9},i,*p[K];
    for (i=0; i<K; i++) {
        p[i]=&x[i];
    }
    bubble(p,K);
    for (i=0; i<K; i++) {
        printf("%d",x[i]);
    }
    printf("\n");
}



