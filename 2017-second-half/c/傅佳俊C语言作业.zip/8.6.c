//
//  main.c
//  8.6
//
//  Created by 傅佳俊 on 2017/12/21.
//  Copyright © 2017年 fujiajun. All rights reserved.
//

#include <stdio.h>
//8.6
int findsub(char *str1,char *str2){
    int i=0,n=0;
    while (str1[i]!='\0') {
        if (str1[i]==str2[0]) {
            return i+1;
            break;
        }
        i++;
    }
    return 0;
}

main() {
    //    // insert code here...
    char str1[]="wherever",str2[]="er";
    printf("%d",findsub(str1, str2));

}



