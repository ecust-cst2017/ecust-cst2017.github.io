//
//  main.c
//  7.11
//
//  Created by 傅佳俊 on 2017/12/19.
//  Copyright © 2017年 fujiajun. All rights reserved.
//


#include <stdio.h>
#define N 4
//7.11
int change(int x[N][N],int mode){
    int i,j,temp;
    if (mode==1) {
        for (i=0; i<N; i++) {
            for (j=i+1; j<N; j++) {
                temp=x[i][j];
                x[i][j]=x[j][i];
                x[j][i]=temp;
            }
        }
        for (i=0; i<N; i++) {
            for (j=0; j<N; j++) {
                printf("%4d",x[i][j]);
            }
            printf("\n");
        }
    }
    else{
        for (i=0; i<N; i++) {
            for (j=N-i-2; j>=0; j--) {
                temp=x[i][j];
                x[i][j]=x[N-j-1][N-i-1];
                x[N-j-1][N-i-1]=temp;
            }
        }
        for (i=0; i<N; i++) {
            for (j=0; j<N; j++) {
                printf("%4d",x[i][j]);
            }
            printf("\n");
        }
    }
    return 0;
}

main() {
//    // insert code here...
    int i,j,mode,a[N][N]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
    for (i=0; i<N; i++) {
        for (j=0; j<N; j++) {
            printf("%4d",a[i][j]);
        }
        printf("\n");
    }
    printf("输入转置模式");
    scanf("%d",&mode);
    change(a, mode);
}




