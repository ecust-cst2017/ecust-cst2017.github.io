#include <stdio.h>

int main(int argc, char const *argv[])
{
	int wordcount,linecount,newword,newline;
	char x;
	FILE *fp;

	fp = fopen("test","rb");

	wordcount = linecount = newword =newline=  0;

	while(!feof(fp))
	{
		x=fgetc(fp);
		if(newline == 0)
		{
			linecount++;
			newline =1;
		}

		if(x == ' ')
		{
			newword =0;
			continue;
		}

		if(x == '\n')
		{
			newline = 0;
			newword = 0;
			continue;
		}

		if(newword == 0&& x>32)
		{
			wordcount++;
			newword =1;
		}
	}

	fclose(fp);

	printf("word number =%d,line number=%d",wordcount,linecount);

	return 0;
}