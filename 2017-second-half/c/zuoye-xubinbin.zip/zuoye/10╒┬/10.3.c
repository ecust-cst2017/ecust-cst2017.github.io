#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct  
{
	char no[10];
	char name[10];
	char sex[2];
	int score;
	
} student;

int main(int argc, char const *argv[])
{
	student stu; 
	char s[30]={0};
	FILE * fp1,*fp2,*fp3;

	fp1 = fopen("test.dat","r");
	fp2 = fopen("men","w");
	fp3 = fopen("women","w");

	while(!feof(fp1))
	{
		fgets(stu.no,10,fp1);

		if(!strcmp(stu.no,""))
			break;

		printf("number = %s\n",stu.no);

		fgets(stu.name,10,fp1);
		printf("name = %s\n",stu.name);

		fgets(stu.sex,3,fp1);
		printf("sex = %s\n",stu.sex);

		fgets(s,4,fp1);
		stu.score =atio(s);

		fgets(s,2,fp1);

		printf("score = %d\n",stu.score);


		if(stu.sex[0]=='m')
			fprintf(fp2,"%9s,%9s,%2s,%3d\n",stu.no,stu.name,stu.sex,stu.score);
		else if(stu.sex[0]=='w')
			fprintf(fp3,"%9s,%9s,%2s,%3d\n",stu.no,stu.name,stu.sex,stu.score);

		stu.no[0]='\0';
	}

	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
	
	return 0;
}