#include "stdio.h"

#define N 2

typedef struct  
{
	char no[10];
	char name[10];
	char sex[2];
	int score;
	
} student;

int main()
{
	student stu ;
	FILE *fp;
	char s[10]={0};
	int i=0;

	fp =fopen("test.dat","w");

	while(i++<N)
	{
		printf("输入学号：\n");
		gets(stu.no);

		printf("输入姓名：\n");
		gets(stu.name);

		printf("输入性别：\n");
		gets(stu.sex);

		printf("输入分数：\n");
		scanf("%d",&stu.score);

		gets(s);

		printf("%9s,%9s,%2s,%3d\n",stu.no,stu.name,stu.sex,stu.score);
		fprintf(fp,"%9s,%9s,%2s,%3d\n",stu.no,stu.name,stu.sex,stu.score);
	}

	fclose(fp);
}
