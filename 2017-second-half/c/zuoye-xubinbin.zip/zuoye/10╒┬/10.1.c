/* 10.1 将C程序写入到 source.C中
*
*/
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char const *argv[])
{ 

	FILE *fp;
	
	char  ch;


	if((fp=fopen("source.c","w")) ==NULL);
	{
		printf("文件打开失败！\n");
		exit(0);
	}
	
	

	while(1)
	{
		ch = getchar();

		if(ch!=EOF)
		{
				fputc(ch,fp);
		}
	
	}
	

	fclose(fp);

	return 0;
}