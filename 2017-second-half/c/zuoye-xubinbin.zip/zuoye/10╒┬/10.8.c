
#include <stdio.h>

#define N 10

int main (void)
{ 

	FILE *fp;
	
	int a[N];

	int i,temp,flag;


	fp=fopen("d:\\input.txt","rb");

	fread(a,2,N,fp);

	fclose(fp);

	for(i=0;i<N;i++)
	{
		printf("%d\n",a[i]);
	}

	do{
		flag=0;
		for(i=1;i<N;i++)
		{
			if(a[i-1]<a[i])
			{
				temp =a[i-1];
				a[i-1] =a[i];
				a[i]=temp;
				flag =1;
			}
		}
	}while(flag);

	fp =fopen("d:\\output.txt","wb");

	fwrite(a,2,N,fp);
	
	fclose(fp);

	for(i=0;i<N;i++)
	{
		printf("%d\n",a[i]);
	}
	

	fclose(fp);
}