
#include <stdio.h>
#include <stdlib.h>


#define L sizeof(GOODS)
#define N   20

typedef struct 
{
	char  name[20];
	float price;
	int in_amount;
	int stock;
}GOODS;

int main(int argc, char const *argv[])
{
	int count ,i,j;
	FILE *fp;
	GOODS x,good[N]={0};

	if((fp=fopen("goods.dat","wb")) == NULL)
	{
		printf("文件打开失败！\n");
		exit(0);
	}

	for(count =0;;count++)
	{
		printf("%d\n",count+1);
		scanf("%s%f%d%d",x.name,x.price,&x.in_amount,&x.stock);
		if(x.price ==0)
			break;
		fwrite(&x,L,1,fp);
	}

	fclose(fp);

	fp=fopen("goods.dat","rb");

	count =0;

	while(!feof(fp))
	{
		if(fread(&good[count],L,1,fp)!=1)
			break;
		count++;
	}
	fclose(fp);

	for(i=0;i<count;i++)
	{
		for(j=i+1;j<count;j++)
		{
			if(good[i].stock>good[j].stock)
			{
				x=good[i];
				good[i]=good[j];
				good[j]=x;
			}
		}
	}

	fp=fopen("goodsort.dat","wb");

	for(i=0;i<count;i++)
	{
		fwrite(&good[i],L,1,fp);
	}

	fclose(fp);

	return 0;
}