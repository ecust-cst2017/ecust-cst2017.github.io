
#include <stdio.h>
#include <stdlib.h>


#define L sizeof(int)

int main(int argc, char const *argv[])
{
	int a,b,read_flag1,read_flag2;
	FILE *fp1,*fp2,*fp3;
	
	fp1 =fopen("a1.dat","rb");
	fp2 =fopen("a2.dat","rb");
	fp3 =fopen("a3.dat","wb");

	read_flag1 = read_flag2 =1;

	while(!feof(fp1)&& !feof(fp2))
	{
		if(read_flag1)
		{
			if(fread(&a,L,1,fp1) !=1 )
				break;
		}
		
		if(read_flag2)
		{
			if(fread(&b,L,1,fp2) !=1 )
				break;
		}
		
		if(a<b)
		{
			fwrite(&a,L,1,fp3);
			read_flag1 =1;
			read_flag2 =0;
		}
		else if(a>b)
		{
			fwrite(&b,L,1,fp3);
			read_flag1 =0;
			read_flag2 =1;
		}
		else
		{
			read_flag1 = 0;
			read_flag2 = 1;
		}
	}


	if(read_flag1 == 0)
	{
		fwrite(&a,L,1,fp3);
		while(!feof(fp1))
		{
			if(fread(&a,L,1,fp1) !=1 )
				break;
			fwrite(&a,L,1,fp3);
		}
	}


	if(read_flag2 == 0)
	{
		fwrite(&b,L,1,fp3);
		while(!feof(fp2))
		{
			if(fread(&b,L,1,fp1) !=1 )
				break;
			fwrite(&b,L,1,fp3);
		}
	}

	fclose(fp1);
	fclose(fp2);
	fclose(fp3);

	fp3 =fopen("a3.dat","rb");
	
	for(;fread(&a,L,1,fp1) !=0;)
	{
		printf("%d",a);
	}

	fclose(fp3);

	return 0;
}