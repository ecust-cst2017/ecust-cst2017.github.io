#include <stdio.h>

int main(int argc, char const *argv[])
{
	char x,y,str1[80],str2[80];
	int i,j,equalflag,lineend1,lineend2;
	FILE *fp1,*fp2;

	fp1 =fopen("test1.txt","r");
	fp2 =fopen("test2.txt","r");

	i=0;equalflag =1;lineend2 =lineend1= 0;

	while(!feof(fp1)&&!feof(fp2))
	{
		x=fgetc(fp1);
		y=fgetc(fp2);

		if(x!=y)
		{
			if(x!='\n')
			{
				str1[i] =x;
			}
			else
			{
				str1[i] ='\0';
				lineend1 =1;
			}


			if(y!='\n')
			{
				str2[i] =y;
			}
			else
			{
				str2[i] ='\0';
				lineend2 =1;
			}

			equalflag =0;
			break;
		}


		if(x=='\n')
		{
			i=0;
			continue;
		}

		if(x>32)
		{
			str1[i] =str2[i] =x;
			i++;
		}
	}

	j=i;

	if(!equalflag)
	{
		while(!feof(fp1)&&!lineend1)
		{
			x=fgetc(fp1);
			if(x=='\n')
			break;
			str1[++i]=x;

		}

		while(!feof(fp2)&&!lineend2)
		{
			y=fgetc(fp2);
			if(y=='\n')
			break;
			str2[++i]=y;

		}

		str1[++i]='\0';
		str1[++j]='\0';
		printf("第一次不相同的是：\n%s\n 和 \n%s\n",str1,str2 );
	}
	else
	{
		printf("两个文件一模一样\n");
	}

	fclose(fp1);
	fclose(fp2);

	return 0;
}