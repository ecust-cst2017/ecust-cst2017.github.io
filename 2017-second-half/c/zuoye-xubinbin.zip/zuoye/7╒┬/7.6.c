/* 7.6 改写递归函数
*
*/
double power(double x,int n)
{
  if (n==0) 
	 return 1;

  if (n==1) 
	  return x;

  if (n>1)  
	  return (x*power(x,n-1));
}

int main (void)
{ 
	float x,z;

    scanf ("%f",&x);

    printf("x=%f\n",x);

    z=power(x,4);

    printf("z=%f\n",z);
}