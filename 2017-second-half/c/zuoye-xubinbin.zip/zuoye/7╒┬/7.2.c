/* 7.2 编写函数求值
*
*/
#include <stdio.h>
#include <math.h>


double  factor(int k)
{
	int i=1;
	double  j=1.0;

	while(k-- !=0)
	{
		j=j*(i++);
	}
	return j;
}


int main(void)
{
	int m ,n;
	
	double  y;

	while(1)
	{
		printf("请输入m和n :");
		scanf("%d%d",&m,&n);
		
		if(m-n<0)
		{
			printf("m 必须大于 n !\n");
		}
		else
		{
			y= factor(m)/factor(n)*factor(m-n);

			printf("结果等于 =%f\n",y);
		}
	}
}