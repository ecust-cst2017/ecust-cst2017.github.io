/* 7.3 reverse
*
*/
#include <stdio.h>
#include <string.h>


void reverse(char * s)
{
	char  p[10]={0};
	int i=0,len =0;

	len = strlen(s);

	while(len-- !=0)
	{
		p[i++]=*(s+len);
	}
	strcpy(s,p);

}


int main(void)
{
	char x[]="abcde";
	reverse(x);

	printf("反转后的字符串为：%s\n",x);
}