/* 7.1 编写函数求值
*
*/
#include <stdio.h>
#include <math.h>


double fun(double t,double m)
{
	return	t/(m*m+sqrt(1+2*m+3*m*m));
}


int main(void)
{
	double x;
	scanf("%f",&x);
	printf("a =%f\n",func(3.5,x));

	scanf("%f",&x);
	printf("b =%f\n",func(x-6.3,x*x));

	scanf("%f",&x);
	printf("c =%f\n",func(1.0,exp(x)));

	scanf("%f",&x);
	printf("d =%f\n",func(sin(x),sin(x)));

	
}
