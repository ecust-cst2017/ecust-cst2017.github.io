/* 7.8 输出最长的单词
*
*/
#include <stdio.h>
#include <string.h>

void longstr (char * string)
{
	char str1 [20]={0};
	char str2 [20]={0};

	int i,count =0;

	int len =strlen(string);
	
	for(i=0;i<len;i++)
	{
		if(('A' <= string[i] && string[i] <= 'Z')|| ('a' <= string[i]&&  string[i] <= 'z'))
		{
			str1[count++] = string[i];
	
		}
		else
		{
			if(strlen(str1)>= strlen(str2))
			{
				strcpy(str2,str1);
				memset(str1,0,sizeof(str1));
			}
			count =0;
		}
	}

	if(strlen(str1)> strlen(str2))
	{
		printf("最长的单词是 %s\n",str1);
	}
	else if(strlen(str1)== strlen(str2))
	{
		printf("最长的单词是 %s 和 %s \n",str2,str1);
	}
	else
	{
		printf("最长的单词是 %s\n",str2);
	}
}

int main (void)
{ 
	char string[20]={0};

	while(1)
	{
		printf("请输入字符串 ：\n");

		scanf ("%s",&string);

		longstr(string);
	}
}