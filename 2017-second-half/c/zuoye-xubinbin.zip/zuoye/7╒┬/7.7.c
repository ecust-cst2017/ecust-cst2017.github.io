/* 7.7 求素数
*
*/
#include <stdio.h>


int isprime (int n)
{
	int m =n-1;
	while(m!=1)
	{
		if(n%(m--)==0)
		return 0;
	}
	return 1;
}

int main (void)
{ 
	int m;
	while(1)
	{
		printf("请输入3-100 之间的一个整数 ：\n");

		scanf ("%d",&m);
		m += 1;
		while(m--!=3)
		{
			if(isprime(m)==1)
			printf("%d 是素数\n",m);
		}
	}
}