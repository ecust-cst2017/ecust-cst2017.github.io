
#include<stdio.h>

struct worker
 {
   int num;
   char name[8];
   char sex;
   char title[8];
   float pay;
 }

 main()
 {
     struct worker person[5]={{001,"张三",'F',"讲师",920},
                              {002,"李四",'M',"副教授",1200},
    			                    {003,"王五",'F',"讲师",920},
                              {004,"赵六",'F',"教授",1500},
    			                    {005,"陈七",'M',"讲师",920} } ;
      
      int i;

      for (i=0;i<5;i++)
      { 
          printf("%-3d",person[i].num);
          printf("%-8s ",person[i].name);
          printf("%-3c ",person[i].sex);
          printf("%-8s",person[i].title);
          printf("%.2f",person[i].pay);
          printf ("\n");
       }
}