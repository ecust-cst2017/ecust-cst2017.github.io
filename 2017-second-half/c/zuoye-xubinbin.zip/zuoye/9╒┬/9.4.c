#include<stdio.h>
#include<string.h>

struct worker
 {
   int num;
   char name[8];
   char sex;
   char title[8];
   float pay;
 }

 main()
 {
     struct worker person[5]={{001,"����",'F',"��ʦ",920},
                              {002,"����",'M',"������",1200},
    			                    {003,"����",'F',"��ʦ",920},
                              {004,"����",'F',"����",1500},
    			                    {005,"����",'M',"��ʦ",920} } ;
      
	 struct worker temp;

      int i ,j;

      for (i=0;i<4;i++)
	  {
		  for(j=0;j<4-i;j++)
		  { 
				if(strcmp(person[j].name,person[j+1].name)>0)
				{
					temp = person[j];
					person[j] = person[j+1];
					person[j+1] = temp;
				}
		   }
	  }

	    for (i=0;i<5;i++)
	  {
		  
		  printf("%-3d",person[i].num);
		  printf("%-8s ",person[i].name);
		  printf("%-3c ",person[i].sex);
		  printf("%-8s",person[i].title);
		  printf("%.2f",person[i].pay);
		  printf ("\n");
		   
	  }
}