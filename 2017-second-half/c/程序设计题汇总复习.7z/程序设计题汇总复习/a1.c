#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
// P63 5.9
// desc :  求Fibonacci数列的前20项。Fibonacci数列的特点是：第一、二次项的值都为1，从第三项开始，每一项都是前两项之和

main()
{
    int a[20],i,n=20,m=0;
    a[0]=1;a[1]=1;
    for(i=2;i<n;i++)
        a[i]=a[i-1]+a[i-2];
    for(i=0;i<n;i++)
    {
        printf("%5d",a[i]);
        m++;
        if(m%5==0)
            printf("\n");
    }
}