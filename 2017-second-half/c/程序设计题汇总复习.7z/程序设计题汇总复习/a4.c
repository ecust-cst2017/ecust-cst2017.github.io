#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
//  P85 6.6设int a[2][3],b[3][2],把a数组的行，列互换并写入到b数组中

main()
{
	char a[11],b[11],c[21];
	int i,j,k,n;
	printf("请输入一个长度不超过10的字符串：");
	gets(a);
	printf("请再输入一个长度不超过10的字符串：");
	gets(b);
	strcpy(c,a);
	strcat(c,b);
	puts(c);
	n=strlen(c);
	for(i=0;i<n-1;i++)
		for(j=0;j<n-1;j++)
			if(c[j]>c[j+1])
			{
				k=c[j];
				c[j]=c[j+1];
				c[j+1]=k;
			}
	puts(c);
}