#include<stdio.h>
//
//  date: 2018.01.14
//  Author: 丁帅帅
//  Version 1.0
//  Email: dingshsh@yoozoo.com
//  Copyright © 2017年 dingshuaishuai. All rights reserved.
//
//  计科172_丁帅帅_26170635
// P85 6.4讲两个字符串按升序合并
main()
{
	int i=0;
	while(i%2!=1&&i%3!=2&&i%5!=4&&i%6!=5)
		{
			i=i+7;
		}
	printf("%d\n",i );
}